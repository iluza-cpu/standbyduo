# StandBy Duo APK 프로젝트

## APK 만드는 법 (가장 쉬운 방법: GitHub)
1. github.com 에서 새 저장소 생성 → 이 폴더 내용 전체 업로드 (.github 폴더 포함)
2. 저장소 상단 [Actions] 탭 → "Build APK" 실행 (push 하면 자동 실행)
3. 완료 후 Artifacts 의 StandByDuo-apk 다운로드 → 압축 풀고 app-debug.apk 설치

## 안드로이드 스튜디오
폴더 열기 → Build > Build APK(s)

## HTML 수정
app/src/main/assets/index.html 만 바꾸면 됩니다.
